//
//  CookCollectionCell.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation
import UIKit
import AVKit
class CookCollectionCell:UICollectionViewCell{
    
    @IBOutlet weak var thumbil: UIImageView!
    
    @IBOutlet weak var videoText: UILabel!
    
    @IBOutlet weak var videoLock: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    func cookGetData(data:RecipeModal){
        
        if data.category == .ordinory{
            videoLock.isHidden = true
        }else{
            videoLock.isHidden = false
        }
    }
    
    
    private func generateThumbnail(for url: URL) -> UIImage? {
           let asset = AVAsset(url: url)
           let imageGenerator = AVAssetImageGenerator(asset: asset)
           imageGenerator.appliesPreferredTrackTransform = true
           var time = asset.duration
           time.value = min(time.value, 2)
           do {
               let cgImage = try imageGenerator.copyCGImage(at: time, actualTime: nil)
               return UIImage(cgImage: cgImage)
           } catch {
               return nil
           }
       }
}
