//
//  RecipeModal.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation

class CookCreate{
    static let shared = CookCreate()
    
    var recipeCollection = [
        RecipeModal(videoUrl: "", category: .premium, videoContent: "Premium"),
        RecipeModal(videoUrl: "", category: .ordinory, videoContent: ""),
        RecipeModal(videoUrl: "", category: .ordinory, videoContent: ""),
        RecipeModal(videoUrl: "", category: .premium, videoContent: ""),
        RecipeModal(videoUrl: "", category: .ordinory, videoContent: ""),
        RecipeModal(videoUrl: "", category: .premium, videoContent: ""),
        RecipeModal(videoUrl: "", category: .ordinory, videoContent: ""),
        RecipeModal(videoUrl: "", category: .ordinory, videoContent: "")
    ]
  
}


struct RecipeModal{
    let videoUrl:String
    let category:Categorytype
    let videoContent:String
}

enum Categorytype{
    case premium
    case ordinory
}
 
