//
//  RecipeVC.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class RecipeVC: UIViewController {

    @IBOutlet weak var recipeCollectionView: UICollectionView!
    var modalData = CookCreate()
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
    }
    func registerCell(){
        recipeCollectionView.register(UINib(nibName: "cookCell", bundle: nil), forCellWithReuseIdentifier: "CookCollectionCell")
    }

}
extension RecipeVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return modalData.recipeCollection.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CookCollectionCell", for: indexPath) as! CookCollectionCell
        let data = modalData.recipeCollection[indexPath.item]
        cell.cookGetData(data: data)
//        cell.foodName.text = data.foodname
//        cell.searchTumbile.image = UIImage(named: data.thumbile)
//        cell.amount.text = "$ \(data.rupees)"
//        cell.rating.text = data.rating
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.size.width - 64) / 2
        return CGSize(width: width, height: 150)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 16
    }

    
}
