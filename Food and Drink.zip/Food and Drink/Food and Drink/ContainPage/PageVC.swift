//
//  PageVC.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class PageVC: UIPageViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
