//
//  ContainViewController.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class ContainViewController: UIViewController{
  

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var containpageController: UIView!
    @IBOutlet  var actionBtn:[UIButton]!
    var pageController:UIPageViewController!
    var currentIndex = 0
    var titleString = ["Home","Recipe","Orders","Notification","Profile"]
    override func viewDidLoad() {
        super.viewDidLoad()
        didmovePageController()
        pageController.dataSource = self
        pageController.delegate = self
        pageController.setViewControllers([controllerShow(index: currentIndex)!], direction: .forward, animated: true,completion: nil)
        UpdateUI(index:currentIndex)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
    }
    func didmovePageController() {
        self.pageController = storyboard?.instantiateViewController(withIdentifier: "PageVC") as! PageVC
        pageController.view.frame = containpageController.bounds
        self.containpageController.addSubview(self.pageController.view)
    }
    func controllerShow(index:Int)-> UIViewController? {
        switch index{
        case 0:
            return HomeVC(nibName: "HomeView", bundle: nil)
        case 1:
            return RecipeVC(nibName: "RecipeView", bundle: nil)
        case 2:
            return FavoriteVC(nibName: "FavotiteView", bundle: nil)
    
        case 3:
            return NotificationVC(nibName: "NotificationController", bundle: nil)
        case 4:
            return ProfileVC(nibName: "ProfileView", bundle: nil)
       
        default:
            return nil
            
        }
    }
    func UpdateUI(index:Int){
        for i in 0..<actionBtn.count{
            if i == index{
                actionBtn[i].tintColor = UIColorConstant.select
                titleLbl.text = titleString[i]
            }else{
                actionBtn[i].tintColor = UIColorConstant.unselct
            }
        }
    }
    @IBAction func sideMenuBtn(_ sender: UIButton) {
        let bundle = Bundle(for: SidemenuVC.self)
        let nextVc = SidemenuVC(nibName: "SideMenuView", bundle: bundle)
        nextVc.modalPresentationStyle = .overFullScreen
        nextVc.modalTransitionStyle = .crossDissolve
        self.present(nextVc, animated: false)
    }
  
    @IBAction func tabBtn(_ sender: UIButton) {
     if let index = actionBtn.firstIndex(of: sender){
         print(index)
         if index == currentIndex{
             return
         }else if index > currentIndex{
             guard let nextVC = controllerShow(index:index)else{
                  return
             }
             pageController.setViewControllers([nextVC], direction: .forward, animated: true)
             
         }else if currentIndex > index{
             guard let nextVC = controllerShow(index:index)else{
                  return
             }
             pageController.setViewControllers([nextVC], direction: .reverse, animated: true)
         }
         currentIndex = index
         UpdateUI(index:currentIndex)
     }
    }
    
    @IBAction func searchVc(_ sender: UIButton) {
        let bundle = Bundle(for: SearchVC.self)
        let nextVc = SearchVC(nibName: "SearchView", bundle: bundle)
        navigationController?.pushViewController(nextVc, animated: true)
    }
    
}
extension ContainViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if ((viewController as? HomeVC)?.index) != nil {
            return nil
        } else if ((viewController as? RecipeVC)?.index) != nil {
            return self.controllerShow(index:0)
        }
        else if ((viewController as? FavoriteVC)?.index) != nil {
            return self.controllerShow(index:1)
        }
        else if ((viewController as? NotificationVC)?.index) != nil {
            return self.controllerShow(index:2)
        } else if ((viewController as? ProfileVC)?.index) != nil {
            return self.controllerShow(index:3)
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if ((viewController as? HomeVC)?.index) != nil {
            return self.controllerShow(index:1)
        } else if ((viewController as? RecipeVC)?.index) != nil {
            return self.controllerShow(index:2)
        }
        else if ((viewController as? FavoriteVC)?.index) != nil {
            return  self.controllerShow(index:3)
        }
        else if ((viewController as? NotificationVC)?.index) != nil {
            return  self.controllerShow(index:4)
        }
        return nil
    }
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if !completed{
            return
        }
        if let firstViewController = pageViewController.viewControllers?.first {
             if firstViewController is HomeVC {
                 currentIndex = 0
             } else if firstViewController is RecipeVC {
                 currentIndex = 1
             } else if firstViewController is FavoriteVC {
                 currentIndex = 2
             } else if firstViewController is NotificationVC {
                 currentIndex = 3
             }else if firstViewController is ProfileVC {
                 currentIndex = 4
             }
            UpdateUI(index:currentIndex)
         }
      

    }
    
}

