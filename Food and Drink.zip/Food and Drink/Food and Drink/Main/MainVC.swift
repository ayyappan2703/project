//
//  ContainPageController.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class MainVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        redirectHomeScreen()
        // Do any additional setup after loading the view.
    }
    
    func redirectHomeScreen(){
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
         let vc = storyBoard.instantiateViewController(identifier: "ContainViewController") as! ContainViewController
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
}
