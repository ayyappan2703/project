//
//  ProfileVC.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class ProfileVC: UIViewController {

    @IBOutlet weak var ProfileTableView: UITableView!
    
    var viewModal = SideMenuData()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        registerCell()
    }
    func registerCell(){
        ProfileTableView.register(UINib(nibName: "sideMenuCell", bundle: nil), forCellReuseIdentifier: "SideMenuCell")
    }


}
extension ProfileVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModal.profileDataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
        let data = viewModal.profileDataList[indexPath.item]
        cell.profileMenuData(data: data)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

