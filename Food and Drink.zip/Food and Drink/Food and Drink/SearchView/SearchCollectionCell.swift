//
//  SearchCollectionCell.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation
import UIKit
class SearchCollectionCell:UICollectionViewCell{
    
    @IBOutlet weak var containView: UIView!
    @IBOutlet weak var searchTumbile: UIImageView!
    
    @IBOutlet weak var foodName: UILabel!
    
    @IBOutlet weak var amount: UILabel!
    
    @IBOutlet weak var rating: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        containView.layer.borderWidth = 1
        containView.layer.borderColor = UIColorConstant.unselct?.cgColor
        containView.layer.cornerRadius = 24
        
    }
}
