//
//  SearchVC.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class SearchVC: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var noresultVew: UIView!
    @IBOutlet weak var searchCollectionView: UICollectionView!
    
    @IBOutlet weak var noresultLabll: UILabel!
    var viewModal = SearchData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
        registerCell()
        keyBoardReaponsse()
        searchCollectionView.contentInset.bottom = 50
    }
    override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
        searchTextField.text = ""
    }
    func keyBoardReaponsse(){
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneButtonTapped))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        // Create a toolbar
        let toolbar = UIToolbar()
        toolbar.items = [flexibleSpace, doneButton]
        toolbar.sizeToFit()
        searchTextField.inputAccessoryView = toolbar
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    func registerCell(){
        searchCollectionView.register(UINib(nibName: "SearchCell", bundle: nil), forCellWithReuseIdentifier: "SearchCollectionCell")
    }
    
    @objc func keyboardWillShow(notification: Notification) {
        if let keyboardHeight = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.height {
            print("Notification: Keyboard will show")
        }
    }
    @objc func keyboardWillHide(notification: Notification) {
        print("Notification: Keyboard will hide")
    }
    @objc func doneButtonTapped(){
        searchTextField.resignFirstResponder()
    }
    
    @objc func textFieldDidChange(text:UITextField){
        viewModal.searchData = viewModal.searchText(text: text.text ?? "")
        if viewModal.searchData.count > 0{
            noresultVew.isHidden = true
            searchCollectionView.isHidden = false
            searchCollectionView.reloadData()
        }else{
            noresultVew.isHidden = false
            searchCollectionView.isHidden = true
            noresultLabll.text = "There are no result for \(text.text ?? ""). Try a new search"
        }
    }
    @IBAction func backBtn(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
}
extension SearchVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModal.searchData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchCollectionCell", for: indexPath) as! SearchCollectionCell
        let data = viewModal.searchData[indexPath.item]
        cell.foodName.text = data.foodname
        cell.searchTumbile.image = UIImage(named: data.thumbile)
        cell.amount.text = "$ \(data.rupees)"
        cell.rating.text = data.rating
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.size.width - 32) / 1
        return CGSize(width: width, height: 150)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 16
    }

    
}
