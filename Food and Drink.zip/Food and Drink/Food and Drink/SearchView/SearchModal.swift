//
//  SearchModal.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation
import UIKit
class SearchData{

    static let shared = SearchData()
     var searchData = [SearchModal]()
    var searchArr = [SearchModal(thumbile: "pizza1", foodname: "Pizza Margherita", rupees: 499.0, rating:  "4.8"),
                     SearchModal(thumbile: "cafe", foodname: "Cappuccino", rupees: 89, rating:  "4.2"),
                     SearchModal(thumbile: "pizza3", foodname: "California Pizza", rupees: 399, rating: "3.5"),
                     SearchModal(thumbile: "ham", foodname: "Ham", rupees: 200, rating: "2.3"),
                     SearchModal(thumbile: "cheese", foodname: "Cheese", rupees: 299, rating: "5"),
                     SearchModal(thumbile: "soda-icon", foodname: "Soda", rupees: 99, rating: "4.2"),
                     SearchModal(thumbile: "shrimp-icon", foodname: "Fish", rupees: 1099, rating: "4.9"),
                     SearchModal(thumbile: "tomato", foodname: "Tomato", rupees: 99, rating: "4.1"),
                     SearchModal(thumbile: "garlic", foodname: "Garlic", rupees: 299, rating: "4.0"),
                     SearchModal(thumbile: "pizza1", foodname: "Meat pizza", rupees: 1019, rating: "4.2"),
                     SearchModal(thumbile: "cafe", foodname: "cold brew", rupees: 199, rating: "4.2"),
                     SearchModal(thumbile: "cheese", foodname: "Sweat Cheese ", rupees: 100, rating: "5.0"),
                     SearchModal(thumbile: "ham", foodname: "Sweat Ham ", rupees: 99, rating: "4.2"),
                     SearchModal(thumbile: "cafe", foodname: "Caffe macchiato", rupees: 199, rating: "5.0")]
    
    
    func searchText(text:String)-> [SearchModal]{
        let filterData = searchArr.filter{$0.foodname.lowercased().contains(text.lowercased())}
        return filterData
    }
    
}
struct SearchModal{
    let thumbile:String
    let foodname:String
    let rupees:Double
    let rating :String
}

