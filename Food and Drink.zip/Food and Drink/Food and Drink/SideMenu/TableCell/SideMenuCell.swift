//
//  SideMenuCell.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class SideMenuCell: UITableViewCell {

    @IBOutlet weak var thumbile: UIImageView!
    
    @IBOutlet weak var sideMenuLbl: UILabel!
    @IBOutlet weak var sideMenuBtn: UIButton!
    var profilAndSideMenuBool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func sideMenudata(data:SidemenuModal){
        thumbile.image = UIImage(named: data.image)
        sideMenuLbl.text = data.content
    }
    func profileMenuData(data:SidemenuModal){
        thumbile.image = UIImage(named: data.image)
        sideMenuLbl.text = data.content
    }

}
