//
//  SidemenuVC.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class SidemenuVC: UIViewController {

    
    @IBOutlet weak var sideView: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    
    var viewModal = SideMenuData()
    override func viewDidLoad() {
        super.viewDidLoad()
        sideMenuCellRegister()
        initAnimateView(animateView: sideView, alphaView: view)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showBottomSheet(animateView: sideView, bgView: view)
    }
    
    func sideMenuCellRegister(){
        let register = UINib(nibName: "sideMenuCell", bundle: nil)
        tableView.register(register, forCellReuseIdentifier: "SideMenuCell")
    }
    
    private func removeHamburger() {
        hideBottomSheet(animateView: sideView, bgView: view) {
                        self.dismiss(animated: false)
        }
    }
    func showBottomSheet(animateView: UIView, bgView: UIView?, completion: (() -> Void)? = nil){
        let color = UIColor.black.withAlphaComponent(0.5)
        UIView.animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1,options: [.curveLinear],animations:
         ({
            animateView.transform = CGAffineTransform.identity
            bgView?.backgroundColor = color
        })){ _ in
            if let completion = completion{
                completion()
            }
        }
        
    }
    
    func hideBottomSheet(animateView: UIView, bgView: UIView?, completion: (() -> Void)? = nil){
        UIView.animate(withDuration: 0.5,
            delay: 0.0,
            usingSpringWithDamping: 1,
            initialSpringVelocity: 1,
            options: [ .curveLinear],
            animations: ({
                self.initAnimateView(animateView: animateView, alphaView: bgView)
            })){ _ in
            if let completionHandler = completion{
                completionHandler()
            }
        }
        
    }
    func initAnimateView(animateView: UIView, alphaView: UIView?){
        let y: CGFloat = 0
        let x = -animateView.frame.width
        animateView.transform = CGAffineTransform.init(translationX: x, y: y)
        alphaView?.backgroundColor = .clear
    }

    @IBAction func closeBtn(_ sender: UIButton) {
        removeHamburger()
    }
    
}
extension SidemenuVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModal.sidemenuDataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
        let data = viewModal.sidemenuDataList[indexPath.item]
        cell.sideMenudata(data: data)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}
