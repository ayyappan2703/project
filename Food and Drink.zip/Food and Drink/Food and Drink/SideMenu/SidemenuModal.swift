//
//  sidemenuModal.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation
import UIKit
class SideMenuData{
    static let shared = SideMenuData()
    var sidemenuDataList = [SidemenuModal(image: "", content: "Manage address", type: .manage),SidemenuModal(image: "", content: "Contact support", type: .contact),SidemenuModal(image: "", content: "Privacy Policy", type: .privacyPolicy),SidemenuModal(image: "", content: "Term and condition", type: .termCondition)]
    
    var profileDataList = [SidemenuModal(image: "", content: "Account and Profile", type: .profile),SidemenuModal(image: "Maps", content: "Manage Address", type: .manage),SidemenuModal(image: "", content: "Write a review", type: .review),SidemenuModal(image: "", content: "Refer to a Friend", type: .referFriend)]
}
struct SidemenuModal{
    let image:String
    let content:String
    let type:Sidemenutype
}
enum Sidemenutype{
    case privacyPolicy
    case termCondition
    case contact
    case manage
    case profile
    case review
    case referFriend
    
}
