//
//  UIColorConstant.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import Foundation
import UIKit

class UIColorConstant{
    static let onboardColor = UIColor(named: "onboardActionContainView")
    static let primaryColor = UIColor(named: "Primary")
    static let secondaryColor = UIColor(named: "Secondary")
    static let thirdColor = UIColor(named: "Third")
    static let finalColor = UIColor(named: "Final")
    static let unselct = UIColor(named: "unselct")
    static let select = UIColor(named: "Select")
}
