//
//  OnboardCell.swift
//  JioSnap
//
//  Created by Ayyapan on 26/06/24.
//

import UIKit

class OnboardCell: UICollectionViewCell {
    
    @IBOutlet weak var onboardImage: UIImageView!
    
    override  func awakeFromNib() {
        super.awakeFromNib()

    }

}
