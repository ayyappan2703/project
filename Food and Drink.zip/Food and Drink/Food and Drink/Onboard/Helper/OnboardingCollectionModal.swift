//
//  CollectionModal.swift
//  JioSnap
//
//  Created by Ayyapan on 26/06/24.
//

import Foundation

struct OnboardingCollectionModal{
    let title:String
    let subTitle:String
    let thumbnail:String
}
