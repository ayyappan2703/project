//
//  OnboardVC.swift
//  JioSnap
//
//  Created by Ayyapan on 26/06/24.
//

import UIKit

class OnboardVC: UIViewController {
    
    @IBOutlet weak var onboardCollectionView: UICollectionView!
 
    @IBOutlet weak var pageControllerDot: UIPageControl!
    
    @IBOutlet weak var onboardingTitle: UILabel!
    
    @IBOutlet weak var onboardingSubTitle: UILabel!
    
    @IBOutlet weak var actionContainView: UIView!
    @IBOutlet weak var startContainView: UIView!
    
    var currentIndex = 0
    var slideShowTimer:Timer!
    var OnboardingCollectionData = [
        OnboardingCollectionModal(title: "Filters", subTitle: "Elevate your selfies\nwith trendy filters", thumbnail: "Onboarding1"),
        OnboardingCollectionModal(title: "Reels" , subTitle: "Get ready to steal the spotlight\nwith JioSnap Reels", thumbnail: "Onboarding2"),
        OnboardingCollectionModal(title: "Events", subTitle: "Effortlessly plan events and\nshare photos", thumbnail: "Onboarding3"),
        OnboardingCollectionModal(title: "Photos", subTitle: "Sync memories\nfrom everywhere", thumbnail: "Onboarding4"),
        OnboardingCollectionModal(title: "Faces & Places", subTitle: "Organize memories with AI enabled\nface detection and place recognition", thumbnail: "Onboarding5"),
        OnboardingCollectionModal(title: "Music", subTitle: "Access your music files &\ntune in to Internet Radio", thumbnail: "Onboarding6")]

    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)

        actionContainView.layer.cornerRadius = actionContainView.frame.size.height / 2
        actionContainView.layer.backgroundColor =  UIColorConstant.onboardColor?.cgColor

    }
    func loadNextData() {
        if OnboardingCollectionData.count - 1 > currentIndex{
            currentIndex += 1
        }
    
      }
      func loadPreviousData() {
          if currentIndex > 0{
              currentIndex -= 1
          }

      }

    func stopTimer(){
        if let timer = self.slideShowTimer , timer.isValid {
            self.slideShowTimer.invalidate()
        }
    }
 
    @objc func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        switch gesture.direction {
        case .left:
            loadNextData()
        case .right:
            loadPreviousData()
        default:
            break
        }
        let newIndex = IndexPath(item: currentIndex, section: 0)
        onboardCollectionView.scrollToItem(at: newIndex, at: .centeredHorizontally, animated: false)
        
    }
    func gotoHomePage(){
        stopTimer()
    
    }
    func onBoardDataShowing(data:OnboardingCollectionModal){
        DispatchQueue.main.async {
            self.onboardingTitle.text = data.title
            self.onboardingSubTitle.text = data.subTitle
        }
       
    }
    
    @IBAction func onboardSkip(_ sender: UIButton) {
        gotoHomePage()
    }
    

    @IBAction func onboardNext(_ sender: UIButton) {
        if OnboardingCollectionData.count - 1 > currentIndex{
            currentIndex += 1
            let newIndex = IndexPath(item: currentIndex, section: 0)
            onboardCollectionView.scrollToItem(at: newIndex, at: .centeredHorizontally, animated: false)
        }
    }
    

    
}
extension OnboardVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return OnboardingCollectionData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnboardCell", for: indexPath) as! OnboardCell
        let data = OnboardingCollectionData[indexPath.row]
//        onBoardDataShowing(data:data)
        cell.onboardImage.image = UIImage(named: data.thumbnail)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        currentIndex = indexPath.row
        onBoardDataShowing(data:OnboardingCollectionData[indexPath.row])
        self.pageControllerDot.currentPage = indexPath.row
 
     
        if OnboardingCollectionData.count - 1 == currentIndex{
            startContainView.isHidden = false
            actionContainView.isHidden = true
        }else{
            startContainView.isHidden = true
            actionContainView.isHidden = false
        }
    }
}

