//
//  HomeVC.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class HomeVC: UIViewController {
 
    @IBOutlet weak var homeTableView: UITableView!
    
    var listFood = [ListFood(type:.banner, list:"New on the Menu"),ListFood(type: .category, list: "Category"),ListFood(type: .popular, list: "Popular")]
    var populor = [PapulorModal(foodName: "Primavera Pizza", wight: "300", foodImage: "pizza3"),PapulorModal(foodName: "Cafe", wight: "100", foodImage: "cafe"),PapulorModal(foodName: "Primavera pizza", wight: "300", foodImage: "pizza2"),PapulorModal(foodName: "Tomato Juice", wight: "300", foodImage: "tomato"),PapulorModal(foodName: "Stuffed Turnover", wight: "300", foodImage: "ham"),PapulorModal(foodName: "Primavera Pizza", wight: "300", foodImage: "pizza3"),PapulorModal(foodName: "Cafe", wight: "100", foodImage: "cafe"),PapulorModal(foodName: "Primavera pizza", wight: "300", foodImage: "pizza2"),PapulorModal(foodName: "Tomato Juice", wight: "300", foodImage: "tomato"),PapulorModal(foodName: "Stuffed Turnover", wight: "300", foodImage: "ham")]
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
        homeTableView.contentInset.bottom = 50
    }
 
    func registerCell(){

        homeTableView.register(UINib(nibName: "HeaderView", bundle: nil), forHeaderFooterViewReuseIdentifier: "HeaderCell")
        homeTableView.register(UINib(nibName:"BannerTableCell", bundle: nil), forCellReuseIdentifier: "BannerTableCell")
        homeTableView.register(UINib(nibName:"Popular", bundle: nil), forCellReuseIdentifier: "PapulorCell")
       
        homeTableView.register(UINib(nibName:"CategoryTableCell", bundle: nil), forCellReuseIdentifier: "CategoryTableCell")
        
    }
    
}

extension HomeVC:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return listFood.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if listFood[section].type == .category{
            return 1
        }else if listFood[section].type == .popular{
            return populor.count
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if listFood[indexPath.section].type == .category{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryTableCell", for: indexPath) as! CategoryTableCell
            return cell
        }else if listFood[indexPath.section].type == .popular{
            let cell = tableView.dequeueReusableCell(withIdentifier: "PapulorCell", for: indexPath) as! PapulorCell
            let data = populor[indexPath.row]
            cell.papulorFood(data:data)
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "BannerTableCell", for: indexPath) as! BannerTableCell
            return cell
        }
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "HeaderCell") as! HeaderCell
        header.HeaderLbl.text =  listFood[section].list
        
        return header
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if listFood[indexPath.section].type == .category{
            return 120
        }else if listFood[indexPath.section].type == .banner{
            return 200
        }else{
            return 150
        }
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            return 40
    }
}

