//
//  CategoryTableCell.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import Foundation
import UIKit
class CategoryTableCell:UITableViewCell{
    
    @IBOutlet weak var CategoryCollectionView: UICollectionView!
    var CategoryFood = [CategoryListShow(image: "soda-icon", category: "Soft Drink"),CategoryListShow(image: "pizza1", category: "Pizza"),CategoryListShow(image: "shrimp-icon", category: "Sea Food"),CategoryListShow(image: "garlic", category: "Garlic"),CategoryListShow(image: "tomato", category: "Tomato")]
    override func awakeFromNib() {
        super.awakeFromNib()
        CategoryCollectionView.delegate = self
        CategoryCollectionView.dataSource = self
        // Initialization code
        registerCell()
    }
    func registerCell(){
        let bundle = UINib(nibName:"CagetegoryCell", bundle: nil)
        CategoryCollectionView.register(bundle, forCellWithReuseIdentifier: "CategoryCell")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
extension CategoryTableCell:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return CategoryFood.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCell", for: indexPath) as! CategoryCell
        let data = CategoryFood[indexPath.item]
        cell.categorylbl.text = data.category
        cell.thumbile.image = UIImage(named: data.image)
        cell.layer.cornerRadius = 10
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.size.width - 64) / 3
        return CGSize(width: width, height: 120)
    }

    
}
