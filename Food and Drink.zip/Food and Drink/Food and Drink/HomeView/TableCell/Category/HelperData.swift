//
//  Helper.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation
import UIKit
struct CategoryListShow{
    let image:String
    let category:String
    
}

