//
//  MakeResipeCell.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class BannerTableCell: UITableViewCell {

    @IBOutlet weak var BannerCollectionView: UICollectionView!
    
    var bannerImage = ["pizza1","cafe","ham","pizza3","cheese"]
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        cellRegister()
    }
    func cellRegister(){
        BannerCollectionView.register(UINib(nibName: "BannerCollectionCell", bundle: nil), forCellWithReuseIdentifier: "BannerCell")
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
extension BannerTableCell:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bannerImage.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BannerCell", for: indexPath) as! BannerCell
        let data = bannerImage[indexPath.item]
        cell.thumnial.image = UIImage(named: data)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = BannerCollectionView.frame.size.width
        
        return CGSize(width: width, height: 250)
    }

}

