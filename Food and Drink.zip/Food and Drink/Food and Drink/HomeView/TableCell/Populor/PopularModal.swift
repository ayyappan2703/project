//
//  PopularModal.swift
//  Food and Drink
//
//  Created by Arun on 28/07/24.
//

import Foundation
import UIKit
struct PapulorModal{
    let foodName:String
    let wight:String
    let foodImage:String
    
}
