//
//  PapulorCell.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class PapulorCell: UITableViewCell {

    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var foodWight: UILabel!
    @IBOutlet weak var foodImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func papulorFood(data:PapulorModal){
        foodName.text = data.foodName
        foodWight.text = "Weight \(data.wight) gr"
        foodImage.image = UIImage(named: data.foodImage)
    }
}
