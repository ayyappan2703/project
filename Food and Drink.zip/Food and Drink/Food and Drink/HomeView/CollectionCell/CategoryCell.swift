//
//  CategoryCell.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import UIKit

class CategoryCell: UICollectionViewCell {
    
    @IBOutlet weak var thumbile: UIImageView!
    
    @IBOutlet weak var categorylbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
