//
//  BannerCell.swift
//  Food and Drink
//
//  Created by Arun on 27/07/24.
//

import UIKit

class BannerCell: UICollectionViewCell {
    
    @IBOutlet weak var thumnial: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
