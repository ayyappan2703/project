//
//  Helper.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import Foundation

struct  ListFood {
    let type :Types
    let list:String
}
enum Types{
    case category
    case popular
    case banner
}
