//
//  HeaderCell.swift
//  Food and Drink
//
//  Created by Ayyapan on 27/07/24.
//

import Foundation
import UIKit

class HeaderCell:UITableViewHeaderFooterView{
    @IBOutlet weak var HeaderLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
